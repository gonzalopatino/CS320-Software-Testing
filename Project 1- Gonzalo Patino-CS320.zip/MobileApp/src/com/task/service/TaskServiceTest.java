package com.task.service;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Gonzalo Patino
 * Unit tests for the TaskService class.
 * These tests validate the functionality of adding, deleting, and updating tasks by their unique task ID.
 */
public class TaskServiceTest {

    // Declare an instance of TaskService that will be used in each test
    private TaskService taskService;

    /**
     * This method is run before each test to set up a fresh TaskService instance.
     * This ensures that each test runs in isolation with a new TaskService object.
     */
    @BeforeEach
    public void setUp() {
        taskService = new TaskService();  // Initialize TaskService before each test
    }

    /**
     * Test Case: Successfully adding a new task with a unique task ID.
     * Purpose: This test verifies that a task can be added successfully when the task ID is unique.
     * Validation: The task is added and can be retrieved, and all fields are correctly initialized.
     */
    @Test
    public void testAddTaskSuccess() {
        // Act: Add a new task to the service
        taskService.addTask("123", "Task Name", "Task Description");

        // Assert: Verify the task was added successfully
        Task task = taskService.getTask("123");  // Retrieve the task by its ID
        assertNotNull(task, "Task should be added successfully and not be null.");
        assertEquals("Task Name", task.getName(), "Task name should be correctly set.");
        assertEquals("Task Description", task.getDescription(), "Task description should be correctly set.");
    }

    /**
     * Test Case: Attempting to add a task with a duplicate task ID.
     * Purpose: This test verifies that an exception is thrown when trying to add a task with an already existing ID.
     * Validation: An IllegalArgumentException is thrown with the expected error message.
     */
    @Test
    public void testAddTaskDuplicateId() {
        // Arrange: Add a task with the ID "123"
        taskService.addTask("123", "Task 1", "Description 1");

        // Act & Assert: Try to add another task with the same ID and verify that an exception is thrown
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            taskService.addTask("123", "Task 2", "Description 2");
        });

        // Assert: Verify that the correct exception message is thrown
        assertEquals("Task ID already exists.", exception.getMessage(), "Exception message should indicate duplicate task ID.");
    }

    /**
     * Test Case: Successfully deleting an existing task by task ID.
     * Purpose: This test verifies that a task can be deleted successfully when the task ID exists.
     * Validation: After deletion, the task should no longer be retrievable from the service.
     */
    @Test
    public void testDeleteTaskSuccess() {
        // Arrange: Add a task to the service
        taskService.addTask("123", "Task Name", "Task Description");

        // Act: Delete the task using its ID
        taskService.deleteTask("123");

        // Assert: Verify that the task was successfully deleted
        Task task = taskService.getTask("123");
        assertNull(task, "Task should be deleted and should not exist in the service.");
    }

    /**
     * Test Case: Attempting to delete a task with a non-existent task ID.
     * Purpose: This test ensures that an exception is thrown when trying to delete a task with an ID that doesn't exist.
     * Validation: An IllegalArgumentException is thrown with the expected error message.
     */
    @Test
    public void testDeleteTaskNonExistentId() {
        // Act & Assert: Attempt to delete a task with an ID that doesn't exist and verify that an exception is thrown
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            taskService.deleteTask("999");  // Task ID "999" does not exist
        });

        // Assert: Verify that the correct exception message is thrown
        assertEquals("Task ID does not exist.", exception.getMessage(), "Exception message should indicate the task ID does not exist.");
    }

    /**
     * Test Case: Successfully updating an existing task's name and description.
     * Purpose: This test verifies that the name and description of a task can be successfully updated when the task ID exists.
     * Validation: The task's name and description should be updated accordingly.
     */
    @Test
    public void testUpdateTaskSuccess() {
        // Arrange: Add a task to the service
        taskService.addTask("123", "Old Name", "Old Description");

        // Act: Update the task's name and description
        taskService.updateTask("123", "New Name", "New Description");

        // Assert: Verify that the task was updated successfully
        Task task = taskService.getTask("123");
        assertEquals("New Name", task.getName(), "Task name should be updated to 'New Name'.");
        assertEquals("New Description", task.getDescription(), "Task description should be updated to 'New Description'.");
    }

    /**
     * Test Case: Attempting to update a task with a non-existent task ID.
     * Purpose: This test ensures that an exception is thrown when trying to update a task with an ID that doesn't exist.
     * Validation: An IllegalArgumentException is thrown with the expected error message.
     */
    @Test
    public void testUpdateTaskNonExistentId() {
        // Act & Assert: Attempt to update a task with an ID that doesn't exist and verify that an exception is thrown
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTask("999", "New Name", "New Description");  // Task ID "999" does not exist
        });

        // Assert: Verify that the correct exception message is thrown
        assertEquals("Task ID does not exist.", exception.getMessage(), "Exception message should indicate the task ID does not exist.");
    }
}
