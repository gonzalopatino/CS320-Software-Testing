package com.task.service;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/**
 * Gonzalo Patino
 * Unit tests for the Task class.
 * These tests validate that the task object is correctly created, and all constraints on taskId, name, and description are enforced.
 */
public class TaskTest {

    /**
     * Test Case: Successfully creating a task with valid input.
     * Purpose: This test ensures that a Task object is successfully created when valid parameters are provided.
     * Validation: The taskId, name, and description should be correctly initialized.
     */
    @Test
    public void testTaskCreationValid() {
        // Act: Create a new Task object with valid inputs
        Task task = new Task("1234567890", "Task Name", "Task Description");

        // Assert: Verify that all fields are initialized correctly
        assertEquals("1234567890", task.getTaskId(), "Task ID should be correctly initialized.");
        assertEquals("Task Name", task.getName(), "Task name should be correctly initialized.");
        assertEquals("Task Description", task.getDescription(), "Task description should be correctly initialized.");
    }

    /**
     * Test Case: Task ID exceeds the allowed limit of 10 characters.
     * Purpose: This test ensures that an exception is thrown when the taskId exceeds 10 characters.
     * Validation: An IllegalArgumentException should be thrown with the appropriate error message.
     */
    @Test
    public void testTaskCreationInvalidId() {
        // Act & Assert: Attempt to create a Task with a taskId longer than 10 characters
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Task Name", "Task Description");  // Invalid ID (11 characters)
        });

        // Assert: Verify that the correct exception message is thrown
        assertEquals("Task ID must not be null and must be <= 10 characters.", exception.getMessage(), "Exception message should indicate that the taskId is too long.");
    }

    /**
     * Test Case: Task name exceeds the allowed limit of 20 characters.
     * Purpose: This test ensures that an exception is thrown when the task name exceeds 20 characters.
     * Validation: An IllegalArgumentException should be thrown with the appropriate error message.
     */
    @Test
    public void testTaskCreationInvalidName() {
        // Act & Assert: Attempt to create a Task with a name longer than 20 characters
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", "This name is way too long for a task name", "Task Description");  // Invalid name (too long)
        });

        // Assert: Verify that the correct exception message is thrown
        assertEquals("Task name must not be null and must be <= 20 characters.", exception.getMessage(), "Exception message should indicate that the task name is too long.");
    }

    /**
     * Test Case: Task description exceeds the allowed limit of 50 characters.
     * Purpose: This test ensures that an exception is thrown when the task description exceeds 50 characters.
     * Validation: An IllegalArgumentException should be thrown with the appropriate error message.
     */
    @Test
    public void testTaskCreationInvalidDescription() {
        // Act & Assert: Attempt to create a Task with a description longer than 50 characters
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", "Task Name", "This description exceeds the 50-character limit for task descriptions.");  // Invalid description
        });

        // Assert: Verify that the correct exception message is thrown
        assertEquals("Task description must not be null and must be <= 50 characters.", exception.getMessage(), "Exception message should indicate that the task description is too long.");
    }

    /**
     * Test Case: Successfully updating the task's name.
     * Purpose: This test ensures that the task name can be updated with valid input.
     * Validation: The task name should be updated successfully.
     */
    @Test
    public void testSetName() {
        // Arrange: Create a valid Task object
        Task task = new Task("1234567890", "Old Name", "Task Description");

        // Act: Update the task's name
        task.setName("New Name");

        // Assert: Verify that the name was updated successfully
        assertEquals("New Name", task.getName(), "Task name should be updated to 'New Name'.");
    }

    /**
     * Test Case: Successfully updating the task's description.
     * Purpose: This test ensures that the task description can be updated with valid input.
     * Validation: The task description should be updated successfully.
     */
    @Test
    public void testSetDescription() {
        // Arrange: Create a valid Task object
        Task task = new Task("1234567890", "Task Name", "Old Description");

        // Act: Update the task's description
        task.setDescription("New Description");

        // Assert: Verify that the description was updated successfully
        assertEquals("New Description", task.getDescription(), "Task description should be updated to 'New Description'.");
    }
}
