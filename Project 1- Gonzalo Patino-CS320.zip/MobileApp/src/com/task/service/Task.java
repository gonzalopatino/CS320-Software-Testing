package com.task.service;

/**
 * Gonzalo Patino
 * The Task class represents a task object with three fields: taskId, name, and description.
 * This class enforces constraints on each field, including length limits, non-null validation,
 * and immutability of the taskId.
 */
public class Task {

    // Fields
    private final String taskId;    // Unique task ID that cannot be updated
    private String name;            // Task name, can be updated
    private String description;     // Task description, can be updated

    /**
     * Constructor to initialize the Task object.
     * 
     * @param taskId       The unique task ID (non-null, <= 10 characters).
     * @param name         The name of the task (non-null, <= 20 characters).
     * @param description  The description of the task (non-null, <= 50 characters).
     * @throws IllegalArgumentException if any constraints are violated.
     */
    public Task(String taskId, String name, String description) {
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Task ID must not be null and must be <= 10 characters.");
        }
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Task name must not be null and must be <= 20 characters.");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Task description must not be null and must be <= 50 characters.");
        }
        
        this.taskId = taskId;   // Task ID is final and cannot be updated
        this.name = name;       // Name can be updated
        this.description = description;  // Description can be updated
    }

    // Getters for the task fields
    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    // Setter for updating the name, with validation
    public void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Task name must not be null and must be <= 20 characters.");
        }
        this.name = name;
    }

    // Setter for updating the description, with validation
    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Task description must not be null and must be <= 50 characters.");
        }
        this.description = description;
    }
}
