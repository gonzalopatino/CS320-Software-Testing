package com.task.service;

import java.util.HashMap;
import java.util.Map;

/**
 * Gonzalo Patino
 * The TaskService class provides methods to manage tasks.
 * It allows adding, deleting, and updating tasks using their unique task ID.
 */
public class TaskService {
    
    // A HashMap to store tasks, with the task ID as the key
    private Map<String, Task> taskMap;

    /**
     * Constructor: Initializes an empty task service.
     */
    public TaskService() {
        taskMap = new HashMap<>();
    }

    /**
     * Adds a new task to the task service.
     * 
     * @param taskId       The unique task ID.
     * @param name         The name of the task.
     * @param description  The description of the task.
     * @throws IllegalArgumentException if a task with the same ID already exists.
     */
    public void addTask(String taskId, String name, String description) {
        if (taskMap.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID already exists.");
        }
        Task task = new Task(taskId, name, description);
        taskMap.put(taskId, task);
    }

    /**
     * Deletes a task from the task service by its ID.
     * 
     * @param taskId The unique task ID of the task to delete.
     * @throws IllegalArgumentException if the task ID does not exist.
     */
    public void deleteTask(String taskId) {
        if (!taskMap.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID does not exist.");
        }
        taskMap.remove(taskId);
    }

    /**
     * Updates the name and description of a task by its task ID.
     * 
     * @param taskId       The unique task ID.
     * @param name         The new name of the task.
     * @param description  The new description of the task.
     * @throws IllegalArgumentException if the task ID does not exist.
     */
    public void updateTask(String taskId, String name, String description) {
        Task task = taskMap.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task ID does not exist.");
        }
        if (name != null && !name.isEmpty()) {
            task.setName(name);
        }
        if (description != null && !description.isEmpty()) {
            task.setDescription(description);
        }
    }

    /**
     * Retrieves a task by its ID.
     * 
     * @param taskId The unique task ID.
     * @return The Task object or null if not found.
     */
    public Task getTask(String taskId) {
        return taskMap.get(taskId);
    }
}
