package com.appointment;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;

/**
 * The AppointmentServiceTest class contains unit tests for the AppointmentService class.
 * Gonzalo Patino
 * These tests cover:
 *  - Adding a valid appointment.
 *  - Deleting an appointment by ID.
 *  - Handling attempts to add an appointment with a duplicate ID.
 *  - Handling attempts to delete a non-existent appointment.
 * 
 * Each test ensures the expected behavior of the AppointmentService methods using JUnit 5.
 */
public class AppointmentServiceTest {

    // The service object that will be tested
    private AppointmentService appointmentService;

    /**
     * This method sets up the AppointmentService instance before each test.
     * 
     * It ensures that a fresh instance of AppointmentService is available for every test,
     * preventing tests from affecting each other by sharing the same instance.
     */
    @BeforeEach
    public void setUp() {
        appointmentService = new AppointmentService();
    }

    /**
     * Test case for adding a valid appointment.
     * 
     * This test verifies that a valid appointment is added to the service successfully,
     * and that the appointment can be retrieved using its ID.
     */
    @Test
    public void testAddAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000);  // 10 seconds in the future
        Appointment appointment = new Appointment("123", futureDate, "Test Appointment");
        appointmentService.addAppointment(appointment);

        // Assert that the appointment was added and can be retrieved by its ID
        assertEquals(appointment, appointmentService.getAppointment("123"));
    }

    /**
     * Test case for deleting an appointment by ID.
     * 
     * This test verifies that an appointment can be deleted successfully using its ID,
     * and ensures that the appointment is no longer retrievable after deletion.
     */
    @Test
    public void testDeleteAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000);  // 10 seconds in the future
        Appointment appointment = new Appointment("123", futureDate, "Test Appointment");
        appointmentService.addAppointment(appointment);

        // Delete the appointment and verify that it is no longer retrievable
        appointmentService.deleteAppointment("123");
        assertNull(appointmentService.getAppointment("123"));
    }

    /**
     * Test case for handling duplicate appointment IDs.
     * 
     * This test verifies that the service throws an IllegalArgumentException when attempting
     * to add a second appointment with the same ID as an existing appointment.
     */
    @Test
    public void testAddDuplicateAppointmentID() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000);  // 10 seconds in the future
        Appointment appointment1 = new Appointment("123", futureDate, "First Appointment");
        Appointment appointment2 = new Appointment("123", futureDate, "Second Appointment");

        appointmentService.addAppointment(appointment1);

        // Verify that adding a second appointment with the same ID throws an exception
        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.addAppointment(appointment2);
        });
    }

    /**
     * Test case for handling attempts to delete a non-existent appointment.
     * 
     * This test verifies that the service throws an IllegalArgumentException when attempting
     * to delete an appointment that does not exist in the service.
     */
    @Test
    public void testDeleteNonExistentAppointment() {
        // Verify that deleting a non-existent appointment throws an exception
        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.deleteAppointment("nonexistent");
        });
    }
}
