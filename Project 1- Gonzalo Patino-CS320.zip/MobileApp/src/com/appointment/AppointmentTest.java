package com.appointment;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.Test;

/**
 * The AppointmentTest class contains unit tests for the Appointment class.
 * Gonzalo Patino
 * These tests verify:
 *  - Creating a valid Appointment object.
 *  - Handling invalid appointment IDs.
 *  - Handling invalid appointment dates (past dates).
 *  - Handling invalid descriptions (exceeding character limits).
 * 
 * Each test ensures the expected behavior of the Appointment class constructors using JUnit 5.
 */
public class AppointmentTest {

    /**
     * Test case for creating a valid appointment.
     * 
     * This test verifies that an Appointment object is created successfully with valid input values,
     * and that the fields (ID, date, description) are correctly initialized.
     */
    @Test
    public void testValidAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000); // 10 seconds in the future
        Appointment appointment = new Appointment("12345", futureDate, "Valid description");

        // Assert that the appointment fields are correctly initialized
        assertEquals("12345", appointment.getAppointmentID());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Valid description", appointment.getDescription());
    }

    /**
     * Test case for handling an invalid appointment ID.
     * 
     * This test verifies that an IllegalArgumentException is thrown if the appointment ID exceeds 10 characters.
     */
    @Test
    public void testInvalidAppointmentID() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000); // 10 seconds in the future

        // Attempt to create an appointment with an invalid ID (too long)
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Valid description");
        });
    }

    /**
     * Test case for handling an invalid appointment date (in the past).
     * 
     * This test verifies that an IllegalArgumentException is thrown if the appointment date is in the past.
     */
    @Test
    public void testInvalidAppointmentDate() {
        Date pastDate = new Date(System.currentTimeMillis() - 10000); // 10 seconds in the past

        // Attempt to create an appointment with a past date
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", pastDate, "Valid description");
        });
    }

    /**
     * Test case for handling an invalid appointment description (exceeding 50 characters).
     * 
     * This test verifies that an IllegalArgumentException is thrown if the description exceeds 50 characters.
     */
    @Test
    public void testInvalidDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000); // 10 seconds in the future

        // Attempt to create an appointment with an overly long description
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", futureDate, "This description exceeds the fifty character limit allowed.");
        });
    }
}
