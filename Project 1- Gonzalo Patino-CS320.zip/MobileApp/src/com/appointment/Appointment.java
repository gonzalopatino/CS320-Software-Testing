package com.appointment;

import java.util.Date;

/**
 * The Appointment class represents an appointment object with a unique ID, date, and description.
 * Gonzalo Patino
 * This class ensures that:
 *  - The appointment ID is unique, non-null, and does not exceed 10 characters.
 *  - The appointment date is non-null and is not in the past.
 *  - The description is non-null and does not exceed 50 characters.
 */
public class Appointment {

    // Fields for appointment ID, appointment date, and description
    private final String appointmentID;
    private final Date appointmentDate;
    private final String description;

    /**
     * Constructor for the Appointment class.
     * 
     * @param appointmentID A unique ID for the appointment, must not be null and cannot exceed 10 characters.
     * @param appointmentDate The date of the appointment, must not be null and cannot be in the past.
     * @param description A description of the appointment, must not be null and cannot exceed 50 characters.
     * @throws IllegalArgumentException if any of the parameters violate the constraints.
     */
    public Appointment(String appointmentID, Date appointmentDate, String description) {
        // Validate appointment ID: must be non-null and no longer than 10 characters
        if (appointmentID == null || appointmentID.length() > 10) {
            throw new IllegalArgumentException("Invalid appointment ID");
        }
        this.appointmentID = appointmentID;

        // Validate appointment date: must be non-null and cannot be in the past
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid appointment date");
        }
        this.appointmentDate = appointmentDate;

        // Validate description: must be non-null and cannot exceed 50 characters
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }
        this.description = description;
    }

    /**
     * Gets the appointment ID.
     * 
     * @return The unique ID for the appointment.
     */
    public String getAppointmentID() {
        return appointmentID;
    }

    /**
     * Gets the appointment date.
     * 
     * @return The date of the appointment.
     */
    public Date getAppointmentDate() {
        return appointmentDate;
    }

    /**
     * Gets the appointment description.
     * 
     * @return The description of the appointment.
     */
    public String getDescription() {
        return description;
    }
}
