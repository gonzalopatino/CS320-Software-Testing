package com.appointment;

import java.util.HashMap;
import java.util.Map;

/**
 * The AppointmentService class provides functionality to manage appointments.
 * Gonzalo Patino
 * This class allows you to:
 *  - Add appointments.
 *  - Delete appointments by their unique ID.
 *  - Retrieve appointments for testing or verification.
 * 
 * The service uses an in-memory data structure (HashMap) to store appointments,
 * with each appointment identified by a unique ID.
 */
public class AppointmentService {

    // A map to store appointments, keyed by their unique appointment ID
    private Map<String, Appointment> appointments;

    /**
     * Constructor for AppointmentService.
     * 
     * Initializes the in-memory HashMap to store appointments.
     */
    public AppointmentService() {
        appointments = new HashMap<>();
    }

    /**
     * Adds a new appointment to the service.
     * 
     * @param appointment The Appointment object to be added.
     * @throws IllegalArgumentException if an appointment with the same ID already exists.
     */
    public void addAppointment(Appointment appointment) {
        // Check if the appointment ID already exists
        if (appointments.containsKey(appointment.getAppointmentID())) {
            throw new IllegalArgumentException("Appointment ID already exists");
        }
        // Add the appointment to the map
        appointments.put(appointment.getAppointmentID(), appointment);
    }

    /**
     * Deletes an appointment from the service by its ID.
     * 
     * @param appointmentID The unique ID of the appointment to be deleted.
     * @throws IllegalArgumentException if no appointment with the given ID exists.
     */
    public void deleteAppointment(String appointmentID) {
        // Check if the appointment ID exists
        if (!appointments.containsKey(appointmentID)) {
            throw new IllegalArgumentException("Appointment ID not found");
        }
        // Remove the appointment from the map
        appointments.remove(appointmentID);
    }

    /**
     * Retrieves an appointment by its ID.
     * 
     * @param appointmentID The unique ID of the appointment to be retrieved.
     * @return The Appointment object associated with the given ID, or null if not found.
     */
    public Appointment getAppointment(String appointmentID) {
        // Return the appointment from the map, or null if it doesn't exist
        return appointments.get(appointmentID);
    }
}
